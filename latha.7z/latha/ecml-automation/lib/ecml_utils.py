from lxml import objectify as xml_objectify
import collections
import json
from ecml_mapping import *
import re
from itertools import izip


def xml_to_dict(xml_str):
    """ Convert xml to dict, using lxml v3.4.2 xml processing library """
    def xml_to_dict_recursion(xml_object):
        dict_object = xml_object.__dict__
        if not dict_object:
            return xml_object
        for key, value in dict_object.items():
            dict_object[key] = xml_to_dict_recursion(value)
        return dict_object
    return xml_to_dict_recursion(xml_objectify.fromstring(xml_str))



def compareXMLtoJSON(json_response, xml_response, mapping_command):
    

    d1 = json.loads(json_response)
    dict_xml_response_tmp = xml_to_dict(xml_response)
    keys = dict_xml_response_tmp.keys()
    d2 = dict_xml_response_tmp[keys[0]]
    d3 = ecml_mapping[mapping_command]
    
    print 'JSON response from SBI: %s\n\n' % d1
    print '###############################################################################################'
    print 'XML Response from ECML: %s\n\n' % d2
    print '###############################################################################################'
    print 'JSON-XML mapping: %s\n\n' % d3
    print '###############################################################################################'
    
    keys = set(d1.keys()) | set(d2.keys()) | set(d3.keys())
    matched_elements = {}
    unmatched_elements = {}
    null_elements = {}
    null_elements_present = {}
    
    for k in keys:
        if k in d1 and k in d3:
            d1_value = d1[k]
            if d1_value != None:
                if k == 'ont-id':
                    d2_key1 = d3[k].split('+')[0]
                    d2_key2 = d3[k].split('+')[1]
                    d2_value1 = d2[d2_key1]
                    d2_value2 = d2[d2_key2]
                    if d1_value == d2_value1 + '-' + str(d2_value2):
                        matched_elements.update({d2_key1: d2_value1})
                        matched_elements.update({d2_key2: d2_value2})
                    else:
                        print "Ont-id does not match PonSysId + Sequence Number"
                else:
                    d2_key = d3[k]
                    if d2_key in d2:
                        d2_value = d2[d2_key]
                        if str(d1_value) == str(d2_value):
                            matched_elements.update({d2_key:d2_value})
                        else:
                            pass
                    else:
                        # "Not found in xml"
                        unmatched_elements.update({k:d1[k]})
            else:
            	d2_key = d3[k]
            	if d2_key not in d2:
            		null_elements.update({k:d1_value})
            	else:
            		null_elements_present.update({k:d1_value})
        else:
            pass
    print 'Matched Elements (Elements present in both json and XML responses): %s\n\n' % matched_elements
    print '###############################################################################################'
    print 'Elements with null in JSON Response (Not present in the XML response): %s\n\n' % null_elements
    print '###############################################################################################'
    print 'Elements with null in JSON Response (Present in the XML response): %s\n\n' % null_elements_present
    print '###############################################################################################'
    print 'Unmatched Elements (Elements present in JSON Response but not present in XML response : %s\n\n' % unmatched_elements
    print '###############################################################################################'
    return matched_elements, null_elements, unmatched_elements, null_elements_present


def compareXMLtoJSONDiscoveredONT(json_response, xml_response, mapping_command):
    d1 = json.loads(json_response)

    d1 =  d1[0]
    print type(d1)
    dict_xml_response_tmp = xml_to_dict(xml_response)
    d2 = flatten(dict_xml_response_tmp)
    #keys = dict_xml_response_tmp.keys()
    #d2 = dict_xml_response_tmp[keys[0]]
    d3 = ecml_mapping[mapping_command]

    print 'JSON response from SBI: %s\n\n' % d1
    print '###############################################################################################'
    print 'XML Response from ECML: %s\n\n' % d2
    print '###############################################################################################'
    print 'JSON-XML mapping: %s\n\n' % d3
    print '###############################################################################################'
    keys = set(d3.keys())
    print keys
    keys = set(d1.keys()) | set(d2.keys()) | set(d3.keys())
    matched_elements = {}
    unmatched_elements = {}
    null_elements = {}
    null_elements_present = {}

    for k in keys:
        if k in d1 and k in d3:
            d1_value = d1[k]
            if d1_value != None:
                if k == 'ont-id':
                    d2_key1 = d3[k].split('+')[0]
                    d2_key2 = d3[k].split('+')[1]
                    d2_value1 = d2[d2_key1]
                    d2_value2 = d2[d2_key2]
                    if d1_value == d2_value1 + '-' + str(d2_value2):
                        matched_elements.update({d2_key1: d2_value1})
                        matched_elements.update({d2_key2: d2_value2})
                    else:
                        print "Ont-id does not match PonSysId + Sequence Number"
                else:
                    d2_key = d3[k]
                    if d2_key in d2:
                        d2_value = d2[d2_key]
                        if str(d1_value) == str(d2_value):
                            matched_elements.update({d2_key: d2_value})
                        else:
                            pass
                    else:
                        # "Not found in xml"
                        unmatched_elements.update({k: d1[k]})
            else:
                d2_key = d3[k]
                if d2_key not in d2:
                    null_elements.update({k: d1_value})
                else:
                    null_elements_present.update({k: d1_value})
        else:
            pass
    print 'Matched Elements (Elements present in both json and XML responses): %s\n\n' % matched_elements
    print '###############################################################################################'
    print 'Elements with null in JSON Response (Not present in the XML response): %s\n\n' % null_elements
    print '###############################################################################################'
    print 'Elements with null in JSON Response (Present in the XML response): %s\n\n' % null_elements_present
    print '###############################################################################################'
    print 'Unmatched Elements (Elements present in JSON Response but not present in XML response : %s\n\n' % unmatched_elements
    print '###############################################################################################'
    return matched_elements, null_elements, unmatched_elements, null_elements_present


def flatten(d, parent_key='', sep='_'):
    items = []
    for k, v in d.items():
        #new_key = parent_key + sep + k if parent_key else k
        new_key = k if parent_key else k
        if isinstance(v, collections.MutableMapping):
            items.extend(flatten(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)

def get_createCG_request():

    cp_port_index1 = 1
    createCG_req_list = []
    for index in range(1,34):
        ponsysid = 'AUTO' + str(index)
        if index < 14:
            cp_port_index2 = index + 1
            cp_port_index3 = index + 2
            cp_port_index4 = index + 3

            createCGstr = '<Ecml><CreateChannelGroup><TID>E9-1</TID><PonSystemId>'+ponsysid+'</PonSystemId><ChannelTerminations><ChannelTermination>2/1/xp'+str(cp_port_index1)+'<PonId>ABCD2101</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index2)+'<PonId>ABCD2102</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index3)+'<PonId>ABCD2103</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index4)+'<PonId>ABCD2104</PonId></ChannelTermination></ChannelTerminations></CreateChannelGroup></Ecml>'
        elif index >= 14 and index < 26:
            if index == 14:
                cp_port_index1 = cp_port_index1 + 1
                cp_port_index2 = cp_port_index1 + 1
                cp_port_index3 = cp_port_index1 + 2
                cp_port_index4 = cp_port_index1 + 3
            elif index > 14:
                cp_port_index2 = cp_port_index2 + 1
                cp_port_index3 = cp_port_index3 + 1
                cp_port_index4 = cp_port_index4 + 1
            createCGstr = '<Ecml><CreateChannelGroup><TID>E9-1</TID><PonSystemId>'+ponsysid+'</PonSystemId><ChannelTerminations><ChannelTermination>2/1/xp'+str(cp_port_index1)+'<PonId>ABCD2101</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index2)+'<PonId>ABCD2102</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index3)+'<PonId>ABCD2103</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index4)+'<PonId>ABCD2104</PonId></ChannelTermination></ChannelTerminations></CreateChannelGroup></Ecml>'
        elif index >= 26 and index < 34:
            if index == 26:
                cp_port_index1 = cp_port_index1 + 1
                cp_port_index2 = cp_port_index1 + 1
                cp_port_index3 = cp_port_index1 + 2
                cp_port_index4 = cp_port_index1 + 3
            elif index > 26:
                cp_port_index2 = cp_port_index2 + 1
                cp_port_index3 = cp_port_index3 + 1
                cp_port_index4 = cp_port_index4 + 1

            createCGstr = '<Ecml><CreateChannelGroup><TID>E9-1</TID><PonSystemId>'+ponsysid+'</PonSystemId><ChannelTerminations><ChannelTermination>2/1/xp'+str(cp_port_index1)+'<PonId>ABCD2101</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index2)+'<PonId>ABCD2102</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index3)+'<PonId>ABCD2103</PonId></ChannelTermination><ChannelTermination>2/1/xp'+str(cp_port_index4)+'<PonId>ABCD2104</PonId></ChannelTermination></ChannelTerminations></CreateChannelGroup></Ecml>'

        #print createCGstr + '\n'
        createCG_req_list.append(createCGstr)
    return createCG_req_list

def verify_xml_declaration_present(xml_str):
    xml_declaration_present = ''
    xmlRegex = '(<\\?xml)'
    rg = re.compile(xmlRegex, re.IGNORECASE | re.DOTALL)
    match = rg.search(xml_str)
    if match:
        xml_declaration_present = 'True'
    else:
        xml_declaration_present= 'False'
    return xml_declaration_present


if __name__ == '__main__':
    xml_string = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Ecml>\n <RetrieveONTStatusResponse>\n <Response>\n <ResultCode>200</ResultCode>\n <UserMessage>Success</UserMessage>\n </Response>\n <TID>E9-1</TID>\n <Shelf>2</Shelf>\n <Slot>2</Slot>\n <Port>xp4</Port>\n <PonSystemId>E2EA</PonSystemId>\n <OntSequenceNumber>1</OntSequenceNumber>\n <OntProfile>SFU</OntProfile>\n <SubscriberId>88998899</SubscriberId>\n <PonId>0</PonId>\n <ProvisionedPon>2/2/xp4</ProvisionedPon>\n <OperStatus>up</OperStatus>\n <Model>700GE</Model>\n <Vendor>Calix</Vendor>\n <Clei>CLEICode1231aaa</Clei>\n <ONUMACAddr>00:02:5d:f1:88:ed</ONUMACAddr>\n <MTAMACAddr>00:02:5d:f1:aa:bb</MTAMACAddr>\n <lambda>0</lambda>\n <LinkedPon>2/2/xp4</LinkedPon>\n <CurrVersion>v1</CurrVersion>\n <AltVersion>v2</AltVersion>\n <CurrCommitted>true</CurrCommitted>\n <CurrCustVersion>v1</CurrCustVersion>\n <AltCustVersion>v2</AltCustVersion>\n <MfgSerialNumber>123456</MfgSerialNumber>\n <ProductCode>123-456-1231</ProductCode>\n <RangeLength>5673</RangeLength>\n <UpTime>12312312</UpTime>\n <OptSignalLevel>5.3</OptSignalLevel>\n <TxOptLevel>10.6</TxOptLevel>\n <NEOptSignalLevel>12.0</NEOptSignalLevel>\n <UsSdberRate>4</UsSdberRate>\n <DsSdberRate>10</DsSdberRate>\n <AvoRfBurstCount>1234</AvoRfBurstCount>\n <AvoReceivedOpticalPower>3.6</AvoReceivedOpticalPower>\n <AvoAverageReceivedOpticalPower>5.3</AvoAverageReceivedOpticalPower>\n <AvoRfLongBurstCount>5678</AvoRfLongBurstCount>\n </RetrieveONTStatusResponse>\n</Ecml>"""
    # dict_xml_response_tmp = xml_to_dict(xml_string)
    # keys = dict_xml_response_tmp.keys()
    # print keys
    # d2 = dict_xml_response_tmp[keys[0]]
    print d2
    compareXMLtoJSON(d2)