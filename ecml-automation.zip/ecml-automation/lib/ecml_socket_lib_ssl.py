import socket, ssl
import sys
from robot.api import logger

class ecml_socket_lib:
	

	def create_socket_connection_ecml(self, host, port):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.ssl_sock = ssl.wrap_socket(self.sock)
		try:
			# Connect to server and send data
			self.ssl_sock.connect((host, int(port)))
			#self.sock.setblocking(0)
			#logger.info('Connection success to %s %s' % self.host, self.port, also_console=True)
			logger.info('Socket connection to ip %s and port %s successful' % (host, port))

        #except IOError as e:
		except socket.error, msg:
			print 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();
		except:
			print 'Failed to create socket'
		return self.ssl_sock

	def send_data_ecml(self, sock, data):
		try:
			sock.sendall(data + '\n')
		except socket.error, msg:
			print 'Socket Error: Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();

	def get_response_from_ecml(self, sock):
		msg = sock.recv(4096)
		return msg

	def get_realtime_alarms(self, sock, no_of_alarms):

		msgs = []
		for index in range(0, int(no_of_alarms)):
			msgs.append(self.get_response_from_ecml(sock))
		return msgs
		
	def close_connection_ecml(self, sock):
		try:
			sock.close()
		except socket.error, msg:
			print 'Socket Error: Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();


if __name__ == '__main__':
 	sock_obj = ecml_socket_lib()
 	sock = sock_obj.create_socket_connection_ecml('10.103.9.120', 9901)
 	data = '<Ecml><AuthenticationRequest><UserId>admin</UserId><Password>test123</Password><RequestType>VNM</RequestType></AuthenticationRequest></Ecml>'
 	sock_obj.send_data_ecml(sock, data)
 	msg = sock_obj.get_response_from_ecml(sock)
 	print msg

