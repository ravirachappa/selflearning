import socket, ssl
import sys
from robot.api import logger


class ecml_socket_lib:
	# def __init__(self, host, port):
	# 	self.host = host
	# 	self.port = port

	def create_socket_connection_ecml(self, host, port):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock = ssl.wrap_socket(self.sock)
		try:
			# Connect to server and send data

			self.sock.connect((host, int(port)))
			self.sock.settimeout(60)

			logger.info('Socket connection to ip %s and port %s successful' % (host, port))

        #except IOError as e:
		except socket.error, msg:
			print 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();
		except:
			print 'Failed to create socket'
		return self.sock

	def send_data_ecml(self, sock, data):
		try:
			sock.sendall(data + '\n')
		except socket.error, msg:
			print 'Socket Error: Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();

	def get_response_from_ecml(self, sock):
		msg = sock.recv(4096)
		return msg

	def get_realtime_alarms(self, sock, no_of_alarms):

		msgs = []
		for index in range(0, int(no_of_alarms)):
			msgs.append(self.get_response_from_ecml(sock))
		return msgs


	def close_connection_ecml(self, sock):
		try:
			sock.close()
		except socket.error, msg:
			print 'Socket Error: Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
			sys.exit();



if __name__ == '__main__':
	sock_obj = ecml_socket_lib()
	sock = sock_obj.create_socket_connection_ecml('10.103.9.120', 9901)
	#sock_obj.get_realtime_alarm(sock)
	#jobs = []
	#p1 = multiprocessing.Process(target=sock_obj.get_realtime_alarm(sock))
	#p2 = multiprocessing.Process(target=sock_obj.send_alarms())
	#p1.start()
	#p2.start()
	t1 = Thread(target=sock_obj.get_realtime_alarm(sock))
	t2 = Thread(target=sock_obj.send_alarms())
	t1.daemon = True

	t1.start()
	t2.start()

