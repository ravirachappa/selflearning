import requests

class ecml_json_requests:
	def __init__(self):
		self.url_delete_interface = "https://10.103.9.121:18443/rest/v1/config/device/E9-1"
		self.url_create_interface = "https://10.103.9.121:18443/rest/v1/config/device"
		self.url_retrieveONTStatus = "https://10.103.9.121:18443/rest/v1/performance/device/E9-1/ont/E2EA-1/status"
		self.url_retrieveONTPortStatus = "https://10.103.9.121:18443/rest/v1/performance/device/E9-1/ont/E2EA-1/port/g1/status"
		self.url_retrievePONPortStatus = "https://10.103.9.121:18443/rest/v1/performance/device/E9-1/shelf/2/slot/1/port/xp1/status"
		self.url_retrieveMulticastStatus = "https://10.103.9.121:18443/rest/v1/performance/device/E9-1/ont/E2EA-1/port/g1/multicast/status"
		self.url_retrieveDiscoveredONT = "https://10.103.9.121:18443/rest/v1/config/device/E9-1/discovered-ont/"

		self.create_interface_payload = "{\r\n    \"name\": \"E9-1\",\r\n    \"address\": \"10.103.9.125\",\r\n    \"port\": 830,\r\n    \"userName\": \"confdemo\",\r\n    \"password\": \"Calix\",\r\n    \"type\": \"AXOS\",\r\n    \"timeZone\": \"UTC\",\r\n    \"region\": {\r\n                \"name\": \"root\"    \r\n                }\r\n}\r\n"
		self.headers = {
    		'content-type': "application/json",
    		'authorization': "Basic YWRtaW46dGVzdDEyMw==",
    		'accept': "application/json",
    		'accept-language': "en-US,en;q=0.8",
    		'cache-control': "no-cache",
    		}

	def delete_interface(self):
		response = requests.request("DELETE", self.url_delete_interface, headers=self.headers, verify=False)
		return response.text


	def create_interface(self):
		response = requests.request("POST", self.url_create_interface, data=self.create_interface_payload, headers=self.headers, verify=False)
		return response.text

	def retrieveONTStatus(self):
		response = requests.request("GET", self.url_retrieveONTStatus, headers=self.headers, verify=False)
		return response.text

	def retrieveONTPortStatus(self):
		response = requests.request("GET", self.url_retrieveONTPortStatus, headers=self.headers, verify=False)
		return response.text

	def retrievePONPortStatus(self):
		response = requests.request("GET", self.url_retrievePONPortStatus, headers=self.headers, verify=False)
		return response.text

	def retrieveMulticastStatus(self):
		response = requests.request("GET", self.url_retrieveMulticastStatus, headers=self.headers, verify=False)
		return response.text

	def retrieveDiscoveredONT(self):
		response = requests.request("GET", self.url_retrieveDiscoveredONT, headers=self.headers, verify=False)
		return response.text


if __name__ == '__main__':
	obj = ecml_json_requests()
	delete_msg = obj.delete_interface()
	print delete_msg
	create_msg = obj.create_interface()
	print create_msg

payload = "{\r\n  \"userIdentity\": {\r\n   \r\n    \"username\": \"user82\",\r\n    \"firstName\": \"user19\",\r\n    \"lastName\": \"user19\",\r\n    \"email\": \"Trum1960@dayrep.com\",\r\n\"language\": \"en\",\r\n\"country\": \"US\"\r\n  },\r\n  \"password\": \"user123\"\r\n}"